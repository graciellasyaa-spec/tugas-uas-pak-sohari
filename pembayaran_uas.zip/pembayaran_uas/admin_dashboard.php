<?php 
include 'config.php';

// Cek session agar hanya admin yang bisa masuk
if ($_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Logika untuk konfirmasi pembayaran (Approve)
if (isset($_GET['approve'])) {
    $id = $_GET['approve'];
    mysqli_query($conn, "UPDATE pembayaran SET status='lunas' WHERE id=$id");
    header("Location: admin_dashboard.php"); // Refresh halaman
}

// Ambil semua data pembayaran
$data = mysqli_query($conn, "SELECT * FROM pembayaran ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | UAS-Pay</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body class="flex min-h-screen">

    <div class="w-64 glass-card m-4 mr-0 rounded-r-none flex flex-col p-6 text-white border-r-0">
        <h1 class="text-2xl font-black mb-10 tracking-tighter italic">ADMIN.👋</h1>
        <nav class="flex-1 space-y-4">
            <a href="admin_dashboard.php" class="block p-4 bg-white/20 rounded-xl font-bold">Data Pembayaran</a>
            <a href="logout.php" class="block p-4 hover:bg-white/10 rounded-xl transition text-red-300 font-semibold">Keluar</a>
        </nav>
        <div class="text-[10px] opacity-50 uppercase tracking-widest text-center mt-auto">Tech Nusantara 2026</div>
    </div>

    <div class="flex-1 p-8 overflow-auto">
        <div class="glass-card p-8 min-h-full">
            <h2 class="text-3xl font-black text-white mb-8 border-b border-white/10 pb-4 uppercase tracking-tight">Verifikasi Pembayaran</h2>
            
            <div class="table-container shadow-2xl">
                <table class="w-full text-left">
                    <thead>
                        <tr>
                            <th class="p-4 border-b">Mahasiswa (NIM)</th>
                            <th class="p-4 border-b text-center">Metode & Ref</th>
                            <th class="p-4 border-b text-center">Jumlah</th>
                            <th class="p-4 border-b text-center">Bukti</th>
                            <th class="p-4 border-b text-center">Status</th>
                            <th class="p-4 border-b text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = mysqli_fetch_assoc($data)): ?>
                        <tr class="hover:bg-gray-50 transition border-b border-gray-100">
                            <td class="p-4">
                                <div class="font-bold text-gray-800"><?= $row['nama_lengkap'] ?></div>
                                <div class="text-xs text-gray-500 font-mono"><?= $row['nim'] ?></div>
                            </td>
                            <td class="p-4 text-center italic text-blue-600 font-semibold">
                                <?= strtoupper($row['metode']) ?>
                                <br>
                                <span class="text-[10px] text-gray-400 not-italic font-normal">
                                    Ref: <?= !empty($row['kode_bayar']) ? $row['kode_bayar'] : '-' ?>
                                </span>
                            </td>
                            <td class="p-4 text-center font-bold text-gray-700">
                                Rp <?= number_format($row['jumlah']) ?>
                            </td>
                            <td class="p-4 text-center">
                                <a href="uploads/<?= $row['bukti_bayar'] ?>" target="_blank" class="text-indigo-600 font-bold hover:underline text-xs italic">View File</a>
                            </td>
                            <td class="p-4 text-center">
                                <span class="px-3 py-1 rounded-full text-[10px] font-black <?= $row['status'] == 'lunas' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700' ?>">
                                    <?= strtoupper($row['status']) ?>
                                </span>
                            </td>
                            <td class="p-4 text-center">
                                <?php if($row['status'] == 'pending'): ?>
                                    <a href="?approve=<?= $row['id'] ?>" class="btn-primary px-4 py-2 rounded-lg text-[10px] inline-block shadow-md">KONFIRMASI</a>
                                <?php else: ?>
                                    <span class="text-green-500 font-bold text-[10px]">VERIFIED ✓</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        
                        <?php if(mysqli_num_rows($data) == 0): ?>
                        <tr>
                            <td colspan="6" class="p-10 text-center text-gray-400 italic font-medium">Belum ada data pembayaran masuk.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
</html>