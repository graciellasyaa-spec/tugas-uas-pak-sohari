<?php include 'config.php';
if ($_SESSION['role'] != 'mahasiswa') header("Location: login.php");
$uid = $_SESSION['user_id'];

if (isset($_POST['bayar'])) {
    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $metode = $_POST['metode'];
    $jumlah = $_POST['jumlah'];
    $kode_bayar = $_POST['kode_bayar']; 
    
    $bukti = time() . "_" . $_FILES['bukti']['name'];
    move_uploaded_file($_FILES['bukti']['tmp_name'], "uploads/".$bukti);

    mysqli_query($conn, "INSERT INTO pembayaran (mahasiswa_id, nim, nama_lengkap, metode, jumlah, kode_bayar, bukti_bayar) 
                         VALUES ('$uid', '$nim', '$nama', '$metode', '$jumlah', '$kode_bayar', '$bukti')");
    echo "<script>alert('Pembayaran Berhasil Terkirim!'); window.location='mhs_dashboard.php';</script>";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Gateway | UAS-Pay</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="style.css">
    <style>
        .qr-frame {
            position: relative;
            width: 200px;
            height: 200px;
            margin: auto;
            border: 2px solid rgba(255,255,255,0.3);
            border-radius: 20px;
            padding: 10px;
            background: white;
        }
        .scan-line {
            position: absolute;
            width: 100%;
            height: 2px;
            background: #4f46e5;
            top: 0;
            left: 0;
            box-shadow: 0 0 15px #4f46e5;
            animation: scan 2s linear infinite;
        }
        @keyframes scan {
            0% { top: 0; }
            50% { top: 100%; }
            100% { top: 0; }
        }
    </style>
</head>
<body class="p-4 md:p-8">

    <div class="max-w-4xl mx-auto">
        <h1 class="text-3xl font-black text-white mb-8 text-center tracking-tighter italic">PAYMENT CENTER.👋</h1>
        
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            
            <div class="glass-card p-8 flex flex-col justify-center items-center text-center order-2 lg:order-1">
                <div class="mb-6">
                    <h3 class="text-white font-bold text-xl mb-2">QRIS DIGITAL PAYMENT</h3>
                    <p class="text-white/60 text-xs">Scan menggunakan aplikasi Dana, OVO, atau M-Banking Anda</p>
                </div>

                <div class="qr-frame shadow-2xl">
                    <div class="scan-line"></div>
                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=PEMBAYARAN_UAS_MHS_<?= $uid ?>" alt="QR Code" class="w-full h-full object-contain">
                </div>

                <div class="mt-6 space-y-2">
                    <div class="flex items-center justify-center space-x-4 opacity-70">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/e/eb/Logo_dana_blue.svg" class="h-4">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/eb/Logo_ovo.svg/1200px-Logo_ovo.svg.png" class="h-4">
                        <img src="https://upload.wikimedia.org/wikipedia/id/thumb/a/af/LinkAja.svg/1200px-LinkAja.svg.png" class="h-4">
                    </div>
                    <p class="text-white/40 text-[10px] uppercase font-mono mt-4">Merchants ID: UAS-PAY-2026</p>
                </div>
            </div>

            <div class="glass-card p-8 order-1 lg:order-2">
                <form method="POST" enctype="multipart/form-data" class="space-y-4">
                    <div>
                        <label class="text-white/70 text-[10px] font-bold uppercase ml-1">Informasi Mahasiswa</label>
                        <input type="text" name="nim" placeholder="NIM Anda" class="w-full p-4 rounded-xl mt-1" required>
                        <input type="text" name="nama" placeholder="Nama Lengkap" class="w-full p-4 rounded-xl mt-2" required>
                    </div>

                    <div>
                        <label class="text-white/70 text-[10px] font-bold uppercase ml-1">Detail Pembayaran</label>
                        <select name="metode" class="w-full p-4 rounded-xl mt-1 cursor-pointer">
                            <option value="barcode">E-Wallet / QRIS (Scan Samping)</option>
                            <option value="mbanking">Mobile Banking Transfer</option>
                            <option value="manual">Bayar Tunai di Loket</option>
                        </select>
                        <input type="number" name="jumlah" placeholder="Jumlah Nominal (Contoh: 500000)" class="w-full p-4 rounded-xl mt-2" required>
                        <input type="text" name="kode_bayar" placeholder="Masukkan ID Transaksi/Ref Setelah Bayar" class="w-full p-4 rounded-xl mt-2 font-mono text-sm border-dashed border-2">
                    </div>

                    <div>
                        <label class="text-white/70 text-[10px] font-bold uppercase ml-1">Lampiran</label>
                        <input type="file" name="bukti" class="w-full text-white text-xs mt-1" required>
                        <p class="text-white/30 text-[9px] italic mt-1">*Upload screenshot hasil scan atau struk pembayaran</p>
                    </div>

                    <button type="submit" name="bayar" class="btn-primary w-full py-4 rounded-xl shadow-2xl mt-4">
                        Kirim Laporan Bayar
                    </button>
                </form>
            </div>

        </div>

        <div class="mt-8 text-center">
             <a href="logout.php" class="text-white/40 hover:text-white transition text-xs font-bold uppercase tracking-widest border-b border-white/20 pb-1">Kembali ke Dashboard Utama</a>
        </div>
    </div>

</body>
</html>