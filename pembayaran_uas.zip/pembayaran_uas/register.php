<?php include 'config.php';
if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    mysqli_query($conn, "INSERT INTO users (username, password, role) VALUES ('$username', '$password', '$role')");
    header("Location: login.php");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | UAS-Pay Digital</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body class="flex items-center justify-center p-6">

    <div class="glass-card p-10 w-full max-w-md">
        <div class="text-center mb-10">
            <h2 class="text-3xl font-black text-white tracking-tighter">BUAT AKUN.👋</h2>
            <p class="text-white/60 text-sm mt-1 uppercase tracking-widest">Registrasi Pengguna Baru</p>
        </div>

        <form method="POST" class="space-y-5">
            <div>
                <label class="text-white/80 text-xs ml-1 mb-2 block uppercase font-bold">Username / NIM</label>
                <input type="text" name="username" class="w-full p-4 rounded-xl" placeholder="Masukkan NIM..." required>
            </div>
            <div>
                <label class="text-white/80 text-xs ml-1 mb-2 block uppercase font-bold">Password</label>
                <input type="password" name="password" class="w-full p-4 rounded-xl" placeholder="Buat Password..." required>
            </div>
            <div>
                <label class="text-white/80 text-xs ml-1 mb-2 block uppercase font-bold">Role User</label>
                <select name="role" class="w-full p-4 rounded-xl cursor-pointer">
                    <option value="mahasiswa">Mahasiswa (Pembayar)</option>
                    <option value="admin">Admin (Pengelola)</option>
                </select>
            </div>
            
            <button type="submit" name="register" class="btn-primary w-full py-4 rounded-xl shadow-lg mt-4">
                Daftar Akun
            </button>
        </form>
        
        <div class="mt-8 pt-6 border-t border-white/10 text-center text-sm">
            <p class="text-white/60">Sudah punya akun?</p>
            <a href="login.php" class="text-white font-bold hover:underline font-italic italic">Kembali ke Login</a>
        </div>
    </div>

</body>
</html>